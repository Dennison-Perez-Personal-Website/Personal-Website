let A= "Hello Everyone, hope you enjoy!"
alert ("Hello Everyone!")
console.log(A)